# v14 Singularity AI System
Production-ready scaffold with Helm + CI/CD
